# EcoGuard NPO — WEDE5020 Part 3

A responsive multi-page environmental NPO website coursework project.

## Files
- `index.html` — home page and Pretoria example map
- `services.html` — dynamic service cards, search, sort, tabs, FAQ accordion and volunteer modal
- `enquiry.html` — service enquiry form with client-side validation and indicative fee calculation
- `contact.html` — general contact form that prepares an email using `mailto:`
- `style.css` — responsive layout and visual styling
- `main.js` — interactions, validation, dynamic rendering and map setup
- `robots.txt`, `sitemap.xml` — basic search-engine crawl files

## Run locally
Open `index.html` in a browser. An internet connection is needed for the Leaflet map, OpenStreetMap tiles, Google Fonts, jQuery and the Unsplash hero image.

## Important customisation before submission
1. Replace `yourusername` in `robots.txt` and `sitemap.xml` with the actual GitHub username/repository URL.
2. Confirm the organisation's real address, contact details, service fees, schedules and email address. Current prices and event times are illustrative coursework values.
3. Replace the Part 2 feedback examples in the changelog below with the exact feedback received from your lecturer and only claim fixes that you have verified against that feedback.
4. Add your own project/gallery images and meaningful alt text if you add image elements.
5. Update the Facebook share URL and deployed website URL after deployment.

## Part 3 functionality
- Responsive mobile navigation.
- Service cards rendered from a JavaScript data array.
- Service search and sorting by name or cost.
- Clean-Ups / Education / Recycling tabs.
- FAQ accordion using jQuery.
- Volunteer information modal.
- Leaflet map centred on central Pretoria using OpenStreetMap.
- Scroll reveal animation using `IntersectionObserver`.
- Enquiry form validation, including South African phone format (`0` followed by nine digits).
- Indicative fee/schedule display for clean-ups, education and recycling.
- Contact form prepares a message in the user's email application.

## Changelog — Feedback Edits from Part 2
The entries below are **suggested examples from the supplied brief**, not verified lecturer feedback. Replace or confirm them against the actual Part 2 feedback before submission.

- Feedback: Navigation not responsive on mobile — Fix included: added a mobile breakpoint and collapsible navigation in `style.css` and `main.js`.
- Feedback: Images missing alt text — Action: no content images are currently embedded in the HTML; add descriptive `alt` text to every image you add.
- Feedback: No meta descriptions for SEO — Fix included: added a unique meta description to each HTML page.
- Feedback: Forms not validating — Fix included: added required fields, HTML validation and JavaScript checks to the enquiry form.

## SEO and deployment
- Update the sitemap and robots URLs after choosing GitHub Pages or another host.
- Use descriptive page titles, headings, internal links and page-specific meta descriptions.
- Consider submitting the deployed site to relevant South African NPO directories and sharing it through the organisation's social channels. These actions create potential discovery opportunities; backlinks are not guaranteed.
- Enable HTTPS through the hosting provider.
- Before production, use a server-side form endpoint for actual submissions. The demo enquiry form validates locally and does not transmit/store data. The contact form uses `mailto:` and depends on the visitor having an email application configured.

## References
- Leaflet: https://leafletjs.com/
- OpenStreetMap: https://www.openstreetmap.org/copyright
- jQuery: https://jquery.com/
- MDN Web Docs: https://developer.mozilla.org/
- Google Search Central — SEO starter guide: https://developers.google.com/search/docs/fundamentals/seo-starter-guide
